# Problema 2. Calculando la cuota de administración 

def calcularadministracion(nombre, canon, meses):

    if canon < 1200000:
        categoria = "Economico"
        porcentaje = 0.08

    elif canon < 2500000:
        categoria = "estandar"
        porcentaje = 0.10
    
    elif canon < 4500000:
        categoria = "ejecutivo"
        porcentaje = 0.12 

    else:
        categoria = "exclusivo"
        porcentaje = 0.15

    valorpagar = canon * porcentaje * meses

    print("\nNombre: ", nombre,
          "\nCategoria: ", categoria,
          "\nValor a pagar: ", valorpagar)


#Datos de entrada
calcularadministracion("Carlos Gómez", 950000, 6)
calcularadministracion("Ana Martínez", 1800000, 12)
calcularadministracion("Luis Rodríguez", 3200000, 4)
calcularadministracion("Sofía López", 5000000, 12)