#Ejercicio 1 Clasificación del tiempo de entrega de pedidos.

def clasificarEntrega(ciudad, distancia, velocidad):
    tiempo = distancia / velocidad

    if tiempo < 1:
        nivelservicio = "Entrega exprés"
    elif tiempo < 3:
        nivelservicio = "Entrega rápida"
    elif tiempo < 6:
        nivelservicio = "Entrega estándar"
    else:
        nivelservicio = "Entrega lenta"

    print("Datos del envio: ")
    print("Destino: ", ciudad)
    print("Tiempo estimado", tiempo, "horas")
    print("Nivel de servicio: ", nivelservicio)
    print()


# Datos de los pedidos

clasificarEntrega("Palmira", 60.0, 50.0)
clasificarEntrega("Buga", 180.0, 60.0)
clasificarEntrega("Pasto", 380.0, 40.0)
clasificarEntrega("Yumbo", 30.0, 60.0)