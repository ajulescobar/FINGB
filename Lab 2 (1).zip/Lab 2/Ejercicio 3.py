#Ejercicio 3. Calculando el costo de producción de tortas 

def calcularcosto(x):

    if x <= 20:
        costo = 25 * x + 40

    else:
        costo = 18 * x + 180

    print("\nCANTIDAD DE TORTAS: ", x,
          "\nCOSTO TOTAL DE PRODUCCION: ", costo, "miles de pesos")

# Datos de entrada
calcularcosto(15)
calcularcosto(30)
calcularcosto(20)